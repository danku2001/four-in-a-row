function View() {
  const gridBody = document.getElementById('gridBody');
  const colsBar = document.getElementById('colsBar');
  const whoami = document.getElementById('whoami');
  const roomCode = document.getElementById('roomCode');
  const status = document.getElementById('status');

  let rows = 6, cols = 7;
  let cells = [];

  function buildBoard(r, c, onColClick) {
    rows = r; cols = c; cells = [];
    gridBody.innerHTML = '';
    colsBar.innerHTML = '';

    for (let j = 0; j < cols; j++) {
      const b = document.createElement('button');
      b.textContent = '↓ ' + (j + 1);
      b.onclick = () => onColClick(j);
      colsBar.appendChild(b);
    }

    for (let i = 0; i < rows; i++) {
      const tr = document.createElement('tr');
      cells[i] = [];
      for (let j = 0; j < cols; j++) {
        const td = document.createElement('td');
        tr.appendChild(td);
        cells[i][j] = td;
      }
      gridBody.appendChild(tr);
    }
  }

  function drawBoard(boardStr, lastMove) {
    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        const td = cells[i][j];
        const ch = boardStr[i * cols + j];
        td.innerHTML = '';

        if (ch === 'R' || ch === 'Y') {
          const d = document.createElement('div');
          const colorClass = ch === 'R' ? 'red' : 'yellow';

          if (lastMove && lastMove.row === i && lastMove.col === j) {
            d.className = `disc drop ${colorClass}`;
            td.appendChild(d);
            requestAnimationFrame(() => d.classList.add('fall'));
          } else {
            d.className = `disc static ${colorClass}`;
            td.appendChild(d);
          }
        }
      }
    }
  }

  return {
    buildBoard,
    drawBoard,
    setMe: (t) => whoami.textContent = t,
    setCode: (t) => roomCode.textContent = t,
    setStatus: (t) => status.textContent = t,
  };
}
