function get(url, cb) {
  const xhr = new XMLHttpRequest();
  xhr.onreadystatechange = () => {
    if (xhr.readyState === 4) {
      try { cb(null, JSON.parse(xhr.responseText), xhr.status); }
      catch(e) { cb(e, null, xhr.status); }
    }
  };
  xhr.open('GET', url, true);
  xhr.send();
}
