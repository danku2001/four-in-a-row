console.log('app.js loaded');

document.addEventListener('DOMContentLoaded', () => {
  const view = View();
  const btnCreate = document.getElementById('btnCreate');
  const btnJoin = document.getElementById('btnJoin');
  const inpRoom = document.getElementById('room');
  const inpName = document.getElementById('fullname');

  let pid = null;
  let pollTimer = null;
  let boardBuilt = false;
  let lastMoveKey = null; 

  function createGame() {
    const name = (inpName.value || '').trim();
    if (!name) { alert('נא למלא שם'); return; }

    get(`http://localhost:3000/new?name=${encodeURIComponent(name)}`, (err, data, status) => {
      if (err || status !== 200) { alert('שגיאת שרת'); return; }
      pid = data.pid;
      view.setMe(`אתה: ${name} (אדום)`);
      view.setCode(`קוד חדר: ${data.code}`);
      startPolling();
    });
  }

  function joinGame() {
    const code = (inpRoom.value || '').toUpperCase().trim();
    const name = (inpName.value || '').trim();
    if (!code || !name) { alert('נא למלא שם וגם קוד חדר'); return; }

    get(`http://localhost:3000/join?code=${encodeURIComponent(code)}&name=${encodeURIComponent(name)}`, (err, data, status) => {
      if (err || status !== 200) { alert('שגיאת שרת'); return; }
      pid = data.pid;
      const youColor = data.color === 'red' ? 'אדום' : 'צהוב';
      view.setMe(`אתה: ${name} (${youColor})`);
      view.setCode(`קוד חדר: ${data.code}`);
      startPolling();
    });
  }

  function startPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(fetchState, 1200);
    fetchState();
  }

  function fetchState() {
    if (!pid) return;
    get(`http://localhost:3000/state?pid=${encodeURIComponent(pid)}`, (err, data, status) => {
      if (err || status !== 200) return;

      view.setStatus(statusLine(data));
      view.setCode(`קוד חדר: ${data.code}`);

      if (data.rows && data.cols && !boardBuilt) {
        view.buildBoard(data.rows, data.cols, sendMove);
        boardBuilt = true;
      }

      if (data.board) {
        // נזהה האם המהלך האחרון השתנה
        let lmToAnimate = null;
        if (data.lastMove && Number.isInteger(data.lastMove.row) && Number.isInteger(data.lastMove.col)) {
          const key = `${data.lastMove.row},${data.lastMove.col}`;
          if (key !== lastMoveKey) {
            lmToAnimate = data.lastMove;     // מהלך חדש - נאנן
            lastMoveKey = key;
          }
        }
        view.drawBoard(data.board, lmToAnimate);
      }
    });
  }

  function sendMove(col) {
    if (!pid) return;
    get(`http://localhost:3000/move?pid=${encodeURIComponent(pid)}&col=${col}`, (err, data) => {
      if (err) return;
      // אחרי מהלך חדש, הפולינג הבא יזהה lastMove חדש ויניע אנימציה פעם אחת
      fetchState();
    });
  }

  function statusLine(s) {
    if (s.status === 'wait') return 'ממתין לשחקן נוסף...';
    if (s.status === 'playing') return s.turn === 'red' ? 'תור אדום' : 'תור צהוב';
    if (s.status === 'win') return 'יש מנצח';
    if (s.status === 'draw') return 'תיקו';
    return '';
  }

  btnCreate.addEventListener('click', createGame);
  btnJoin.addEventListener('click', joinGame);

  window._create = createGame;
  window._join = joinGame;
});
