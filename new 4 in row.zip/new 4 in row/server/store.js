const db = require('./db');
const { emptyBoard } = require('./gameLogic');

function genCode() {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = ''; for (let i = 0; i < 6; i++) s += abc[Math.floor(Math.random() * abc.length)];
  return s;
}
function genPid() {
  const abc = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = ''; for (let i = 0; i < 16; i++) s += abc[Math.floor(Math.random() * abc.length)];
  return s;
}

function createGame(cb) {
  const code = genCode();
  const board = emptyBoard();
  db.query(
    `INSERT INTO games (code, board, turn, status) VALUES (?, ?, 'red', 'wait')`,
    [code, board],
    (err, result) => err ? cb(err) : cb(null, { id: result.insertId, code, board, turn: 'red', status: 'wait' })
  );
}
function findGameByCode(code, cb) {
  db.query(`SELECT * FROM games WHERE code = ? LIMIT 1`, [code], (err, rows) => err ? cb(err) : cb(null, rows[0] || null));
}
function getPlayers(gameId, cb) {
  db.query(`SELECT * FROM players WHERE game_id = ? ORDER BY id ASC`, [gameId], (e, r) => e ? cb(e) : cb(null, r));
}
function addPlayer(gameId, name, color, cb) {
  const pid = genPid();
  db.query(`INSERT INTO players (game_id, pid, name, color) VALUES (?, ?, ?, ?)`, [gameId, pid, name, color], (err) =>
    err ? cb(err) : cb(null, { pid, color })
  );
}
function getPlayer(pid, cb) {
  db.query(`SELECT * FROM players WHERE pid = ? LIMIT 1`, [pid], (e, r) => e ? cb(e) : cb(null, r[0] || null));
}
function getGameById(id, cb) {
  db.query(`SELECT * FROM games WHERE id = ? LIMIT 1`, [id], (e, r) => e ? cb(e) : cb(null, r[0] || null));
}
function updateAfterMove(gameId, board, turn, status, lastRow, lastCol, cb) {
  db.query(
    `UPDATE games SET board = ?, turn = ?, status = ?, last_move_row = ?, last_move_col = ? WHERE id = ?`,
    [board, turn, status, lastRow, lastCol, gameId],
    (e) => cb(e)
  );
}

module.exports = { createGame, findGameByCode, getPlayers, addPlayer, getPlayer, getGameById, updateAfterMove };
