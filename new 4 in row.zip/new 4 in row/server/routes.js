const { ROWS, COLS, dropDisc, hasFour, isDraw } = require('./gameLogic');
const store = require('./store');

function sendJson(res, code, obj) {
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(obj));
}

function newGame(req, res, url) {
  const name = (url.searchParams.get('name') || '').trim();
  if (!name) return sendJson(res, 400, { error: 'missing name' });

  store.createGame((e1, g) => {
    if (e1) return sendJson(res, 500, { error: 'db' });
    store.addPlayer(g.id, name, 'red', (e2, p) => {
      if (e2) return sendJson(res, 500, { error: 'db' });
      sendJson(res, 200, { pid: p.pid, color: 'red', code: g.code });
    });
  });
}

// GET /join
function join(req, res, url) {
  const code = (url.searchParams.get('code') || '').toUpperCase().trim();
  const name = (url.searchParams.get('name') || '').trim();
  if (!code || !name) return sendJson(res, 400, { error: 'missing params' });

  store.findGameByCode(code, (err, game) => {
    if (err) return sendJson(res, 500, { error: 'db' });

    const ensurePlayers = (g) => {
      store.getPlayers(g.id, (e2, players) => {
        if (e2) return sendJson(res, 500, { error: 'db' });

        if (players.length === 0) {
          store.addPlayer(g.id, name, 'red', (e3, p) => {
            if (e3) return sendJson(res, 500, { error: 'db' });
            sendJson(res, 200, { pid: p.pid, color: 'red', code: g.code });
          });
        } else if (players.length === 1) {
          store.addPlayer(g.id, name, 'yellow', (e3, p) => {
            if (e3) return sendJson(res, 500, { error: 'db' });
            store.updateAfterMove(g.id, g.board, g.turn, 'playing', null, null, (e4) => {
              if (e4) return sendJson(res, 500, { error: 'db' });
              sendJson(res, 200, { pid: p.pid, color: 'yellow', code: g.code });
            });
          });
        } else {
          sendJson(res, 409, { error: 'room full' });
        }
      });
    };

    if (!game) {
      store.createGame((e1, g) => e1 ? sendJson(res, 500, { error: 'db' }) : ensurePlayers(g));
    } else {
      ensurePlayers(game);
    }
  });
}

// GET /state
function state(req, res, url) {
  const pid = url.searchParams.get('pid');
  if (!pid) return sendJson(res, 400, { error: 'missing pid' });

  store.getPlayer(pid, (e, p) => {
    if (e || !p) return sendJson(res, 401, { error: 'bad pid' });
    store.getGameById(p.game_id, (e2, g) => {
      if (e2 || !g) return sendJson(res, 500, { error: 'db' });
      store.getPlayers(g.id, (e3, players) => {
        if (e3) return sendJson(res, 500, { error: 'db' });

        const names = players.map(x => ({ name: x.name, color: x.color }));
        sendJson(res, 200, {
          board: g.board,
          turn: g.turn,
          status: g.status,
          lastMove: g.last_move_row == null ? null : { row: g.last_move_row, col: g.last_move_col },
          you: { pid: p.pid, name: p.name, color: p.color },
          players: names,
          rows: ROWS,
          cols: COLS,
          code: g.code,
        });
      });
    });
  });
}

// GET /move
function move(req, res, url) {
  const pid = url.searchParams.get('pid');
  const col = parseInt(url.searchParams.get('col'), 10);
  if (!pid || isNaN(col)) return sendJson(res, 400, { error: 'missing params' });

  store.getPlayer(pid, (e, p) => {
    if (e || !p) return sendJson(res, 401, { error: 'bad pid' });
    store.getGameById(p.game_id, (e2, g) => {
      if (e2 || !g) return sendJson(res, 500, { error: 'db' });

      if (g.status !== 'playing') return sendJson(res, 200, { ok: false, msg: 'not playing' });

      const yourTurn =
        (g.turn === 'red' && p.color === 'red') ||
        (g.turn === 'yellow' && p.color === 'yellow');
      if (!yourTurn) return sendJson(res, 200, { ok: false, msg: 'not your turn' });
      if (col < 0 || col >= COLS) return sendJson(res, 400, { ok: false, msg: 'bad col' });

      const colorChar = p.color === 'red' ? 'R' : 'Y';
      const dropped = dropDisc(g.board, col, colorChar);
      if (!dropped) return sendJson(res, 200, { ok: false, msg: 'column full' });

      const newBoard = dropped.board;
      let newStatus = 'playing';
      let nextTurn = g.turn === 'red' ? 'yellow' : 'red';

      if (hasFour(newBoard, colorChar)) newStatus = 'win';
      else if (isDraw(newBoard)) newStatus = 'draw';

      store.updateAfterMove(
        g.id,
        newBoard,
        nextTurn,
        newStatus,
        dropped.row,
        dropped.col,
        (e3) => e3 ? sendJson(res, 500, { error: 'db' }) : sendJson(res, 200, { ok: true, status: newStatus })
      );
    });
  });
}

module.exports = { join, state, move, newGame };
