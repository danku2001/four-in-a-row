const ROWS = 6;
const COLS = 7;

function emptyBoard() { return '.'.repeat(ROWS * COLS); }
function at(board, r, c) { return board[r * COLS + c]; }
function setAt(board, r, c, ch) {
  const idx = r * COLS + c;
  return board.slice(0, idx) + ch + board.slice(idx + 1);
}
function dropDisc(board, col, color) {
  for (let r = ROWS - 1; r >= 0; r--) {
    if (at(board, r, col) === '.') return { board: setAt(board, r, col, color), row: r, col };
  }
  return null;
}
function hasFour(board, color) {
  for (let r = 0; r < ROWS; r++)
    for (let c = 0; c <= COLS - 4; c++)
      if (at(board, r, c) === color && at(board, r, c+1) === color && at(board, r, c+2) === color && at(board, r, c+3) === color) return true;
  for (let c = 0; c < COLS; c++)
    for (let r = 0; r <= ROWS - 4; r++)
      if (at(board, r, c) === color && at(board, r+1, c) === color && at(board, r+2, c) === color && at(board, r+3, c) === color) return true;
  for (let r = 0; r <= ROWS - 4; r++)
    for (let c = 0; c <= COLS - 4; c++)
      if (at(board, r, c) === color && at(board, r+1, c+1) === color && at(board, r+2, c+2) === color && at(board, r+3, c+3) === color) return true;
  for (let r = 0; r <= ROWS - 4; r++)
    for (let c = 3; c < COLS; c++)
      if (at(board, r, c) === color && at(board, r+1, c-1) === color && at(board, r+2, c-2) === color && at(board, r+3, c-3) === color) return true;
  return false;
}
function isDraw(board) { return !board.includes('.'); }

module.exports = { ROWS, COLS, emptyBoard, dropDisc, hasFour, isDraw };
