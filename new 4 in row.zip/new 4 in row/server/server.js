const http = require('http');
const { URL } = require('url');
const routes = require('./routes');

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.method !== 'GET') {
    res.writeHead(405, { 'Content-Type': 'text/plain' });
    return res.end('only GET');
  }

  if (path === '/join') return routes.join(req, res, url);
  if (path === '/new')  return routes.newGame(req, res, url); // נתיב חדש
  if (path === '/state') return routes.state(req, res, url);
  if (path === '/move') return routes.move(req, res, url);

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('not found');
});

const PORT = 3000;
server.listen(PORT, () => console.log(`server on http://localhost:${PORT}`));
