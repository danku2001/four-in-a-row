const mysql = require('mysql2');

const conn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'כאן מכניסים את סיסמת הsql שלנו',
  database: 'connect4',
  charset: 'utf8mb4'
});

conn.connect((err) => {
  if (err) {
    console.error('בעיה בחיבור ל-MySQL:', err.message);
    return;
  }
  console.log('מחובר ל-MySQL ');
});

module.exports = conn;
